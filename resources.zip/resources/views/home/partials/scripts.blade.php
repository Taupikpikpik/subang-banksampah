<!-- Required jquery and libraries -->
    <script src="{{asset('vendor/landing')}}/assets/js/jquery-3.3.1.min.js"></script>
    <script src="{{asset('vendor/landing')}}/assets/js/popper.min.js"></script>
    <script src="{{asset('vendor/landing')}}/assets/vendor/bootstrap-5/js/bootstrap.bundle.min.js"></script>

    <!-- cookie js -->
    <script src="{{asset('vendor/landing')}}/assets/js/jquery.cookie.js"></script>

    <!-- PWA app service registration and works -->
    <script src="{{asset('vendor/landing')}}/assets/js/pwa-services.js"></script>

    <!-- swiper script -->
    <script src="{{asset('vendor/landing')}}/assets/vendor/swiperjs-6.6.2/swiper-bundle.min.js"></script>

    <!-- nouislider js -->
    <script src="{{asset('vendor/landing')}}/assets/vendor/nouislider/nouislider.min.js"></script>

    <!-- Customized jquery file  -->
    <script src="{{asset('vendor/landing')}}/assets/js/main.js"></script>
    <script src="{{asset('vendor/landing')}}/assets/js/color-scheme.js"></script>

    <!-- page level custom script -->
    <script src="{{asset('vendor/landing')}}/assets/js/app.js"></script>
    <script src="{{asset('vendor/sweetalert')}}/sweetalert.min.js"></script>
@include('vendor.sweet.alert')